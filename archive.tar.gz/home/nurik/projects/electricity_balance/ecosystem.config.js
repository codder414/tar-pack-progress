module.exports = {
	apps: [
		{
			script: './dist/server.js'
		}
	]
};
